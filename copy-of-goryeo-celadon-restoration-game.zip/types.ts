
export enum GameStage {
  Intro,
  Dusting,
  Assembling,
  Mending,
  Completed,
}
